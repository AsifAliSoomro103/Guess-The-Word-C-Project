#include<iostream>
#include "game_functions.h"

int main(){
	//fstream player_file("Players/Players.txt",ios::app);
	
	//essential variables;
  	int m_opt = 0, p_opt = 0;
  	bool want_main_menu = true;
  	bool want_play_game = true;
  	//start screen
  	while(want_main_menu||want_play_game){
	
	int counter = 0;
  	char temp;
  	if(want_main_menu){
		do{
			system("cls");
			main_menu();
		
	    	cin>>temp;
	    	m_opt = char_to_int(temp);
	    	if(m_opt == 2)
			{
				return 0;
			}
			else if(m_opt == 1)
			{
				m_opt = 0;
			 	break;	
			}

		}while(m_opt != 1 || m_opt != 2);
		
		//player select	               
		do{
			
			if(p_opt == 1)
			{  
				make_player();
			}
			
			else if(p_opt == 2)
			{
				del_player();               	
			}
				
			system("cls");
			counter = p_select_menu();
			cin>>temp; 
			p_opt = char_to_int(temp);   
			
			                                 
	 } while(p_opt <= 1 || p_opt == 2 || p_opt > counter);
}
	 if(want_play_game){
	
	
		 get_player(p_opt); //stores player info in cuurent player struct 
	 
		 get_words(); //stores all words and hints info in words vector
	     
		 char guess_letter; //to get user input
	 
		 get_next_word(); //stores new word in word and new hint in hint
	 
	 	string msg = " "; //to show if wrong/correct guess
	 
	 	while(current_player.chances > 0){
	 	system("cls");
	 	game_title();
	 	level_info();
	 	if(msg != " "){
	 		cout<<msg;
	 	}
		 for(char letter: word){
	 	
			if(is_guessed(letter) || letter == ' '){
	 			cout<<letter<<" ";
			}
			else if(!is_guessed(letter)){
				cout<<"_ ";
			}
		 }	 
		//check if the word is guessed completely
	 	if(guessed_all()){
	 		get_next_word();
	 		guessed_letters.clear();
	 		guessed_letters.push_back(' ');
	 		current_player.score += 1000;
	 		if(current_player.high_score < current_player.score){
	 			current_player.high_score = current_player.score;
			}
	 		current_player.chances = 3;
	 		current_player.reveals += 1;
			save_progress(); 
	 		cout<<"\nCONGRATULATIONS YOU GUESSED THE WORD\n\n T0 MOVE ON NEXT LEVEL ";
			system("PAUSE");
			continue;
	 	}
	 	cout<<"\n\n"<<hint;
	 	cout<<"\n\n\nGuess a Letter: ";
	 	cin>>guess_letter;
	 	if(guess_letter != '1')
	 	    s_capitalize(guess_letter);
	
	 	if(guess_letter == '1' && current_player.reveals >= 1){
	 		reveal_letter();
	 		msg = "\nUsed 1 Reveal!\n\n";
	 		current_player.reveals--;
	 		continue;
		 }
	 	else if(guess_letter == '1' && current_player.reveals < 1){
	 		msg = "\nNO REVEALS LEFT!\n\n";
	 		continue;
		 }
		 if(is_correct(guess_letter) && guess_letter != ' '){
	 		guessed_letters.push_back(guess_letter);
	 		msg = "\nCorrect Guess!\n\n";
	 	}
	 	else if(!is_correct(guess_letter) && guess_letter != ' '){
	 		current_player.chances--;
	 		msg = "\nIncorrect Guess!\n\n";
		 }
	 
		}
	}
	
	
			system("cls"); 
			save_progress();
			game_over();
			cin>>temp;
			s_capitalize(temp);
			if(temp == 'Y'){
				want_main_menu = false;
				want_play_game = true;
			
			}
			else if(temp == 'N'){
				want_main_menu = true;
				want_play_game = true;
			}
			else {
				return 0;	
			}
	
	
		
	}
	
	return 0;
}




