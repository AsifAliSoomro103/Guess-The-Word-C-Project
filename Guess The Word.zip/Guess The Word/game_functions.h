#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <filesystem>
#include <vector>

using namespace std;
//player class
struct player{
	public:
	string name = "";
	int score = 0;
	int high_score = 0;
	int reveals = 3;
	int chances = 3;
};

//global varibales
player current_player;
vector<string> words = {};
int num_of_words = 0;
vector<char> guessed_letters = {' '};
string word;
string hint;

void game_title();//prints game title (at line 55)
void main_menu();//prints main menu (at line 60)
int p_select_menu();//prints player (make/delete/select) menu and returns number of lines printed (at line 66)
void level_info();//prints level info(name,score,high score,reveals,chances) (at line 81)
void game_over(); //prints game over menu (at line 90)

void make_player();//asks and makes new player file and adds new player in Players file(at line 96)
void del_player();//asks and deletes selected player (at line 121)

void get_player(int player_num);//takes player number stores player info from file to current_player struct (at line 158)
void get_words();//stores words and hints from file to vector<string> words (at line 190)
void get_next_word();//stores random word and hint from vector<string> words to word and hint variables (at line 210)

bool player_exist(string name);//checks if player exists, and returns true or false (at line 218)
bool is_guessed(char &letter);//check if the letter is aldready guessed, and returns true/false (at line 231)
bool is_correct(char &guess_letter);//check if the guess is correct(at line 241)
bool guessed_all();//check if all the letters are guessed(at line 251)
void reveal_letter();//reveals a non-guessed letter (at line 269)

void save_progress(); //saves highscore to player file (at line 285)

void s_capitalize(char &guess_letter);//capitalize letters and turns invalid chars to ' ' (at line 294)
int char_to_int(char c); //converts char digits to int digits and returns -1 for non digit entries (at line 304)


//prints game title
void game_title(){
	cout<<"|||||||||||||||||||||||||||GUESS THE WORD|||||||||||||||||||||||||||\n\n";
}

//prints main menu
void main_menu(){
	game_title();
	cout<<"1. Start\n2. Exit\n\nEnter(1 or 2): ";     
}

//prints player make/delete/select menu and returns number of lines printed
int p_select_menu(){
	game_title();
	cout<<"1. Make player\n2. Delete player\n";     
	fstream player_file("Players/Players.txt");	
	string player;
	int counter = 2;
	while(getline(player_file,player)){
		cout<<++counter<<". "<<player<<endl;
	}
	cout<<"\nselect(1 to "<<counter<<"): ";
	player_file.close();
	return counter;
}

//prints level info(name,score,high score,reveals,chances)
void level_info(){
	 cout<<"Player: "<<current_player.name<<endl;
	 cout<<"Score: "<<current_player.score<<endl;
	 cout<<"High Score: "<<current_player.high_score<<endl;
	 cout<<"Chances: "<<current_player.chances<<endl;
	 cout<<"Reveals: "<<current_player.reveals<<"  Press (1) to use"<<endl;	
}

//prints game over menu
void game_over(){
	cout<<"GAME OVER!\n\nSCORE: "<<current_player.score<<"\n\nHIGH SCORE: "<<current_player.high_score;
	cout<<"\n\nPRESS Y TO PLAY AGAIN!\nPRESS N TO GO TO MAIN MENU!\nPRESS OTHER BUTTONS TO EXIT!";
	current_player.score = 0;
    current_player.chances = 3;
    current_player.reveals = 3;
    guessed_letters.clear();
}

//asks and makes new player file and adds new player in Players file
void make_player(){
	string name;
	cout<<"Enter your name: ";
	cin>>name;
	if(player_exist(name))
	{
		cout<<"Player already exists!";
		system("PAUSE");
	}
	else
	{
		fstream player_file("Players/Players.txt",ios::app);
		player_file<<name<<endl;
		player_file.close();
		fstream new_player_file("Players/"+name+".txt",ios::out);
		new_player_file<<"Name: "<<endl;
		new_player_file<<name<<endl;
		new_player_file<<"High Score: "<<endl;
		new_player_file<<0<<endl;
		
		new_player_file.close();	
	}
}

//asks and deletes player file and deletes player from Players file
void del_player() {
    string name;
    cout << "Enter player name to delete: ";
    cin >> name;

    if (!player_exist(name)) {
        cout << "Player does not exist!";
        system("PAUSE");
    } else {
        string line;
        fstream player_file("Players/Players.txt", ios::in);
        fstream next_file("Players/Next.txt", ios::app);

        while (getline(player_file, line)) {
            if (line != name) {
                next_file << line << endl;
            }
        }

        player_file.close();
        next_file.close();

        remove("Players/Players.txt") ;
        rename("Players/Next.txt", "Players/Players.txt");
        remove(("Players/" + name + ".txt").c_str());
    }
}

//takes player number stores player info from file to current_player struct
void get_player(int player_num){
	 
	string line;
	int counter = 1;
	fstream player_file("Players/Players.txt",ios::in);
	
	if(!player_file){
		cout<<"ALL PLAYERS FILE DOES NOT EXIST"<<endl;
		system("PAUSE");
	}
		while(getline(player_file, line)){
			if(counter == (player_num - 2)){
				counter = 1;
				break;
			}
			counter++;
		}
		
	fstream the_player_file("Players/"+line+".txt",ios::in);
	if(!the_player_file){
		cout<<"PLAYER FILE DOES NOT EXIST"<<endl;
		system("PAUSE");
	}
	while(getline(the_player_file, line)){	
		if(counter == 2){
			current_player.name = line;
		}
		else if(counter == 4){
			current_player.high_score = stoi(line);
		}
		counter++;
	}
}  

//stores words from file to vector<string> words
void get_words(){
	string line;
	fstream player_file("Words.txt",ios::in);
	if(player_file){
		
		while(getline(player_file, line)){
			
						
			 words.push_back(line);
			 num_of_words++;
			 
		}
	}
	else{
	 cout<<"Player_file not exists";	
	}
	player_file.close();
}

//stores random word and hint from vector<string> words to word and hint variables
void get_next_word(){
	 srand(time(0));
	 int random = (rand() % num_of_words/2) * 2;
	 word = words[random];
     hint = words[random + 1];
}

//takes name, checks if player exists and returns true or false
bool player_exist(string name){
	string line;	
	fstream player_file("Players/Players.txt",ios::in);
	if(!player_file)
		cout<<"Players file does not exist";
		
	while(getline(player_file, line)){
		
		if(line == name)
		{
			return true;
		}
	}
	return false;
}

//check if the letter is aldready guessed, and returns true/false
bool is_guessed(char &letter){ 
	for(char s: guessed_letters){
		if(s == letter){
			return true;
		}
	}	
	return false;
}

//check if the guess is correct
bool is_correct(char &guess_letter){
	
	for(char letter: word){
		if(guess_letter == letter || (guess_letter - 32) == letter ){
			return true;
		}
	}
	return false;
}

//check if all the letters are guessed
bool guessed_all(){
    bool found;
    for(char letter: word){
        found = false;
        for(char s: guessed_letters){  
            if(s == letter){
                found = true;
                break;
            }
        }   
        if(!found){
            return false;  
        }
    }    
    return true;  
}

//reveals a non-guessed letter
void reveal_letter(){
	for(char letter: word){
		bool guessed = false;
		for(char s: guessed_letters){
			if(s == letter){
				guessed = true;
			}
		}
		if(!guessed){
			guessed_letters.push_back(letter);
			break;
		}
	}
}

//saves highscore into player file 
void save_progress(){
	ofstream write_file("Players/" + current_player.name + ".txt", ios::out);
	write_file<<"Name: "<<endl;
	write_file<<current_player.name<<endl;
	write_file<<"High Score: "<<endl;
	write_file<<current_player.high_score<<endl;
}

//capitalize letters and turns invalid chars to ' '
void s_capitalize(char &guess_letter) {
	
	
	if (int(guess_letter) >= 97 && int(guess_letter) <= 122) {
		
        guess_letter -= 32; 
    }
	else if (int(guess_letter) >= 65 && int(guess_letter) <= 90){
    	
    }
	else{
    	cout<<"Convert succesful to to space ";
    	system("PAUSE");
        guess_letter = ' '; 
	}
}


//converts char digits to int digits and returns -1 for non digit entries
int char_to_int(char c) {
    if (c >= '0' && c <= '9') {
        return c - '0';  
    }
    return -1; 
}

